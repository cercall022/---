-- phpMyAdmin SQL Dump
-- version 4.5.4.1deb2ubuntu2.1
-- http://www.phpmyadmin.net
--
-- Host: localhost
-- Generation Time: Mar 25, 2020 at 10:53 PM
-- Server version: 5.7.29-0ubuntu0.16.04.1
-- PHP Version: 7.2.28-3+ubuntu16.04.1+deb.sury.org+1

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `se62_04`
--

-- --------------------------------------------------------

--
-- Table structure for table `borrow`
--

CREATE TABLE `borrow` (
  `borrow_Id` varchar(15) NOT NULL,
  `borrower_Id` varchar(15) NOT NULL,
  `staff_Id` varchar(15) NOT NULL,
  `teacher_Id` varchar(15) NOT NULL,
  `reason` text CHARACTER SET utf8 NOT NULL,
  `borrow_Date` date NOT NULL,
  `approve` tinyint(1) NOT NULL,
  `cancel` tinyint(1) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `borrower`
--

CREATE TABLE `borrower` (
  `borrower_Id` varchar(15) NOT NULL,
  `borrower_Name` text CHARACTER SET utf8 NOT NULL,
  `borrower_Fac` varchar(5) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `borrow_detail`
--

CREATE TABLE `borrow_detail` (
  `borrow_Id` varchar(15) NOT NULL,
  `product_Id` varchar(50) NOT NULL,
  `amount` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `category`
--

CREATE TABLE `category` (
  `cat_Id` varchar(15) NOT NULL,
  `cat_Name` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `category`
--

INSERT INTO `category` (`cat_Id`, `cat_Name`) VALUES
('1', 'อุปกรณ์เครื่องเขียน'),
('2', 'อุปกรณ์คอมพิวเตอร์'),
('3', 'อุปกรณ์ไฟฟ้า'),
('4', 'บอร์ด');

-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `cat_Id` varchar(15) NOT NULL,
  `product_Id` varchar(50) NOT NULL,
  `product_Name` text CHARACTER SET utf8 NOT NULL,
  `status` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`cat_Id`, `product_Id`, `product_Name`, `status`) VALUES
('1', '1', 'ปากกา', 'ถูกยืม'),
('2', '2', 'เมาส์ wireless', 'ถูกยืม'),
('2', '3', 'คีย์บอร์ด', 'ว่าง'),
('4', '4', '8366', 'ว่าง'),
('1', '55', 'ปากกา3', 'ว่าง');

-- --------------------------------------------------------

--
-- Table structure for table `returning`
--

CREATE TABLE `returning` (
  `returning_Id` varchar(15) NOT NULL,
  `borrow_Id` varchar(15) NOT NULL,
  `returning_Date` date NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `staff`
--

CREATE TABLE `staff` (
  `staff_Id` varchar(15) NOT NULL,
  `staff_Name` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `teacher`
--

CREATE TABLE `teacher` (
  `teacher_Id` varchar(15) NOT NULL,
  `teacher_Name` text CHARACTER SET utf8 NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(12) COLLATE utf8_bin NOT NULL,
  `passwd` varchar(50) COLLATE utf8_bin NOT NULL,
  `name` varchar(50) COLLATE utf8_bin NOT NULL,
  `surname` varchar(50) COLLATE utf8_bin NOT NULL,
  `type` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_bin;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `passwd`, `name`, `surname`, `type`) VALUES
(1, 'admin', 'admin', 'admin', 'admin', 2),
(946253111, 'test', '0', 'test', 'test', 3),
(946253112, 'b6020502074', '555', 'ดนุสรณ์', 'วิจารณกุล', 3),
(946253114, 'b6020501388', '123456', 'พงศธร', 'ทองคำ', 3),
(946253118, 'b6020503828', '123456', 'ปฐมาวดี', 'เลขะพันธ์รัตน์', 3),
(946253124, 'fengsstc', '123', 'ศศิธร', 'ชลรัตน์อมฤต', 2),
(946253125, 'fengncn', '123', 'นุชนาฎ', 'สัตยากวี', 1);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `borrow`
--
ALTER TABLE `borrow`
  ADD PRIMARY KEY (`borrow_Id`),
  ADD KEY `borrower_Id` (`borrower_Id`,`staff_Id`,`teacher_Id`);

--
-- Indexes for table `borrower`
--
ALTER TABLE `borrower`
  ADD PRIMARY KEY (`borrower_Id`);

--
-- Indexes for table `borrow_detail`
--
ALTER TABLE `borrow_detail`
  ADD KEY `borrow_Id` (`borrow_Id`,`product_Id`);

--
-- Indexes for table `category`
--
ALTER TABLE `category`
  ADD PRIMARY KEY (`cat_Id`);

--
-- Indexes for table `product`
--
ALTER TABLE `product`
  ADD PRIMARY KEY (`product_Id`),
  ADD KEY `cat_Id` (`cat_Id`);

--
-- Indexes for table `returning`
--
ALTER TABLE `returning`
  ADD PRIMARY KEY (`returning_Id`),
  ADD KEY `borrow_Id` (`borrow_Id`);

--
-- Indexes for table `staff`
--
ALTER TABLE `staff`
  ADD PRIMARY KEY (`staff_Id`);

--
-- Indexes for table `teacher`
--
ALTER TABLE `teacher`
  ADD PRIMARY KEY (`teacher_Id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=946253126;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
