<?php include("../../lib/phpmailer/PHPMailerAutoload.php");
      include "../../LDAPKU.php";
      include "../../Class/user.class.php";
      include "../../Class/Db.class.php";
?>

<?php
$username=$_POST["username"];

if(user::findByUsername($username)==null)
{
    header('Location: ../../forgotpasswd.php?s=1');}
session_start();
$_SESSION["username"]=$username;
$info=user_authen($username);

header('Content-Type: text/html; charset=utf-8');

$mail = new PHPMailer;
$mail->CharSet = "utf-8";
$mail->isSMTP();
$mail->Host = 'smtp.gmail.com';
$mail->Port = 587;
$mail->SMTPSecure = 'tls';
$mail->SMTPAuth = true;


$gmail_username = "secpekps04@gmail.com"; // gmail ที่ใช้ส่ง
$gmail_password = "cpese62_04"; // รหัสผ่าน gmail
// ตั้งค่าอนุญาตการใช้งานได้ที่นี่ https://myaccount.google.com/lesssecureapps?pli=1


$sender = "ระบบยืมคืนอุปกรณ์ CPE KPS"; // ชื่อผู้ส่ง
$email_sender = "noreply@ibsone.com"; // เมล์ผู้ส่ง
$email_receiver = $info[0]["google-mail"][0]; // เมล์ผู้รับ ***

$subject = "เปลี่ยนรหัสผ่าน"; // หัวข้อเมล์


$mail->Username = $gmail_username;
$mail->Password = $gmail_password;
$mail->setFrom($email_sender, $sender);
$mail->addAddress($email_receiver);
$mail->Subject = $subject;

$email_content = "
	<!DOCTYPE html>
	<html>
	    กรุณากดที link เพื่อทำการตั้งรหัสผ่านใหม่</br>
		<a href='http://158.108.207.4/se62_04/SE/changepasswd.php'>กดเพื่อเข้าเว็บไซต์</a>
	</html>
";

//  ถ้ามี email ผู้รับ
if($email_receiver){
	$mail->msgHTML($email_content);


	if (!$mail->send()) {  // สั่งให้ส่ง email

		// กรณีส่ง email ไม่สำเร็จ
		echo "<h3 class='text-center'>ระบบมีปัญหา กรุณาลองใหม่อีกครั้ง</h3>";
		echo $mail->ErrorInfo; // ข้อความ รายละเอียดการ error
	}else{
		// กรณีส่ง email สำเร็จ
		echo "ระบบได้ส่งข้อความไปเรียบร้อย";
        header('Location: ../../index.php?s=3');
	}
}



?>