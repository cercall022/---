<script>
    function Alert() {
        alert("password กับ confirmpassword ไม่ตรงกัน ");}
</script>
<?php
$sys=$_GET["s"];
if($sys==1)
{
    echo "<body onload=\"Alert();\" >";

}
?>
<script>
    function checkpassword() {
        var passwd = document.getElementById("password");
        var confirmpasswd = document.getElementById("confirmpassword");
        var text =document.getElementById("test");
        if(passwd.value!==confirmpasswd.value)
        {
            text.innerHTML="กรุณากรอก Password ให้ตรงกัน";}
        else
        {
            text.innerHTML="";
        }
    }

</script>
<div align="center">
    <form name="loginForm" id="loginForm" method="post" action="changepwDB.php">
        <fieldset style="width:30%">
            <br/>
            <span style="color: #ffffff;"><legend style="background-color:#595853 ;"><font color="#efefef">เปลี่ยนรหัสผ่าน :</font></legend></span>


            <div>
                <label style="display: inline-block; width: 90px; text-align: right;" for="username">USERNAME: </label>
                <?php
                session_start();
                $username=$_SESSION["username"];

                echo"<input  type=\"text\" name=\"username\" id=\"username\" value=$username >"
                ?>
            </div>
            <div>
                <label style="display: inline-block; width: 90px; text-align: right;" for="password" width="100px">PASSWORD: </label>
                <input class="btn btn-default" type="password" name="password" id="password" >
            </div>
            <div>
                <label style="display: inline-block;  text-align: right;" for="password" >CONFIRM PW: </label>
                <input class="btn btn-default" type="password" name="confirmpassword" id="confirmpassword" onkeyup="checkpassword()">
            </div>
            <div id="test"><font color="red"></font></div>

            <br/>
            <button type="submit" class="btn">Submit</button>
            <button type="reset" class="btn" >Back</button>

        </fieldset>
    </form>
</div>

