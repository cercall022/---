<link rel="stylesheet" href="tab.css">
<link rel="stylesheet" href="TabSide.css">
<link rel="stylesheet" href="table.css">

<?php
include "./Class/user.class.php";
include "header.php";
include "func.php";
include "./Class/product.class.php";
include "./Class/Db.class.php";
include "./Class/category.class.php";
session_start();?>
<script>
    function Alert() {
        alert("ไม่พบคำที่ค้นหาในระบบ");}
</script>

<?php $title = "ระบบยืมคืนอุปรกณ์ CPE KPS";
$sys=$_GET["s"];
if($sys==4) {
    echo "<body onload=\"Alert();\" >";
}


//echo "<div class=\"sidenav\">";
//echo"<a2>คุณ".$_SESSION['users']->getName()."&nbsp".$_SESSION['users']->getSurname()."</a2>";

/*
echo "
            <a href=\"UI_Admin.php\">•ดูอุปกรณ์</a>
            <a href=\"#\">•ดูสถิตการยืมอุปกรณ์</a>
            <a href=\"UI_manage.php\">•จัดการอุปกรณ์</a>
            <a href=\"logout.php\">•Logout</a>
          </div>";*/
?>

<div class="w3-sidebar w3-bar-block w3-light-grey" style="width:20%">
    <div class="w3-container w3-dark-grey ">
        <h3>Welcome :</h3>
        <h5><?php echo"<a2> คุณ ".$_SESSION['users']->getName()."&nbsp".$_SESSION['users']->getSurname()."</a2>"; ?></h5>
    </div>

    <div class="w3-panel w3-blue-grey w3-display-container ">
        <h4>Menu</h4>
    </div>
    <a href="UI_Admin.php" class="w3-bar-item w3-button">ดูอุปกรณ์</a>
    <a href="UI_manage.php" class="w3-bar-item w3-button">จัดการอุปกรณ์</a>
    <a href="#" class="w3-bar-item w3-button">ดูสถิติ</a>
    <button class="w3-bar-item w3-button w3-green w3-mobile" onclick="location.href='logout.php'">Logout</button>
</div>

<div style="margin-left:25%">

    <div class="w3-container">
    <h2>ระบบยืมคืนอุปกรณ์</h2>
        <p>ติดต่อ</p>
        <p>โทรศัพท์: 034-351897 ต่อ 7523 หรือ 099-6954159 </p>
        <p>  Website : http://www.cpe.eng.kps.ku.ac.th </p>
        <p>  Fanpage Facebook : https://www.facebook.com/cpe.eng.kps/</p>
        <p>  ติดต่อผู้ดูแลระบบ : fengsstc@ku.ac.th</p>
    </div>
</div>


<?php
$header=array("ID","ชื่ออุปกรณ์","หมวดหมูู่","สถานะ");
$data=array();
$productlist=Product::findAll();
$i=0;
foreach ($productlist as$prod)
{
    $data[$i]=array($prod->getProductId(),
        $prod->getProductName(),
        FindCatName($prod->getCatId()),
        $prod->getStatus());
    $i++;
}
//
//print_r($data);
echo "</br>";




?>

