
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script>
    function Alert() {
        alert("ลงทะเบียนเสร็จสิ้น\nกรุณา Login เข้าระบบ");}
    function Alert2() {
        alert("ระบบได้ทำการส่ง Link\nสำหรับทำการเปลี่ยน password ให้กับท่านทาง Email\nกรุณาเข้า Email ของท่าน");}
    function Alert3() {
        alert("เปลี่ยน password เสร็จสิ้น\nกรุณา Login เข้าระบบ");}
</script>
<body>
<link rel="stylesheet" href="tab.css">
<div class="logo">• ระบบยืมคืนอุปกรณ์ CPE KPS</div>
</body>


<?php

    $title = "ระบบยืมคืนอุปรกณ์ CPE KPS";


    $sys=$_GET["s"];
    if($sys==1)
    {
        echo "<body onload=\"Alert();\" >";

    }
    if($sys==2)
    {
        echo "Username หรือ Password ผิดพลาด!!";
    }
    if($sys==3)
    {
        echo "<body onload=\"Alert2();\" >";

    }
    if($sys==4)
    {
        echo "<body onload=\"Alert3();\" >";

    }

    //include "header.php";
    session_start();
    if($_SESSION['users']!="")
        header('Location: UI_Admin.php');

?>


    <div align="center">
    <form name="loginForm" id="loginForm" method="post" action="login.php">
        <br style="width:30%">


        <span style="color: #ffffff;"><legend style="background-color:#595853 ; width: 30% "><font color="#efefef">LOGIN :</font></legend></span>

            <span style="color: dimgrey; ">
                <div>
                    <label style="display: inline-block; width: 90px; text-align: right;" for="username">USERNAME :</label>
                    <input class="btn btn-default"  type="text" name="username" id="username" required/>
                </div>
                <div>
                    <label style="display: inline-block; width: 90px; text-align: right;" for="password" width="100px">PASSWORD: </label>
                    <input class="btn btn-default"  type="password" name="password" id="password" required/>

                </div>
                <div>
                    <br/>
                    <a href="register.php">ลงทะเบียน</a>&nbsp;
                    <a href="forgotpasswd.php">ลืมรหัสผ่าน </a>
                </div>
            </span>
                <button type="submit" class="btn">Login</button>
                <button type="reset" class="btn">Cancel</button>

        </fieldset>
    </form>
    </div>


