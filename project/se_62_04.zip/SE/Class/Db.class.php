<?php


class Db {
    private static $instance = NULL;
    private static $dsn = "mysql:dbname=se62_04;host=localhost";
    private static $user = "se62_04";
    private static $pass = "se62_04";
    private function __construct() {}
    private function __clone() {}
    public static function getInstance() {
        if (!isset(self::$instance)) {
            self::$instance = new PDO(self::$dsn,self::$user,self::$pass);
            self::$instance->query("SET NAMES UTF8");
        }
        return self::$instance;
    }
}
?>
