<?php
    class Category
    {   private $cat_Id;
        private $cat_Name;
        private const TABLE = "category";

        /**
         * @return mixed
         */
        public function getCatId()
        {
            return $this->cat_Id;
        }

        /**
         * @param mixed $cat_Id
         */
        public function setCatId($cat_Id): void
        {
            $this->cat_Id = $cat_Id;
        }

        /**
         * @return mixed
         */
        public function getCatName()
        {
            return $this->cat_Name;
        }

        /**
         * @param mixed $cat_Name
         */
        public function setCatName($cat_Name): void
        {
            $this->cat_Name = $cat_Name;
        }
        public static function findById(int $id): ?Category {
            $con = Db::getInstance();
            $query = "SELECT * FROM ".self::TABLE." WHERE cat_Id = $id";
            $stmt = $con->prepare($query);
            $stmt->setFetchMode(PDO::FETCH_CLASS, "Category");
            $stmt->execute();
            if ($prod = $stmt->fetch())
            {
                return $prod;
            }
            return null;
        }
        public static function findAll(): array {
            $con = Db::getInstance();
            $query = "SELECT * FROM ".self::TABLE;
            $stmt = $con->prepare($query);
            $stmt->setFetchMode(PDO::FETCH_CLASS, "Category");
            $stmt->execute();
            $CategoryList  = array();
            while ($prod = $stmt->fetch())
            {
                $CategoryList[$prod->getCatId()] = $prod;
            }
            return $CategoryList;
        }
        public function insert() {
            $con = Db::getInstance();
            $values = "";
            //$this->setCatId($con->lastInsertId());
            foreach ($this as $prop => $val) {
                $values .= "'$val',";
            }
            $values = substr($values,0,-1);
            $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
            //echo $query;
            $res = $con->exec($query);
            return $res;

        }




    }
?>