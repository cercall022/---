<?php

    class user
    {
        private $id;
        private $username;
        private $passwd;
        private $name;
        private $surname;
        private $type;
        private const TABLE = "users";

        /**
         * @return mixed
         */

        public function getId()
        {
            return $this->id;
        }

        /**
         * @param mixed $id
         */
        public function setId($id)
        {
            $this->id = $id;
        }

        /**
         * @return mixed
         */
        public function getUsername()
        {
            return $this->username;
        }

        /**
         * @param mixed $username
         */
        public function setUsername($username)
        {
            $this->username = $username;
        }

        /**
         * @return mixed
         */
        public function getPasswd()
        {
            return $this->passwd;
        }

        /**
         * @param mixed $passwd
         */
        public function setPasswd($passwd)
        {
            $this->passwd = $passwd;
        }

        /**
         * @return mixed
         */
        public function getName()
        {
            return $this->name;
        }

        /**
         * @param mixed $name
         */
        public function setName($name)
        {
            $this->name = $name;
        }

        /**
         * @return mixed
         */
        public function getSurname()
        {
            return $this->surname;
        }

        /**
         * @param mixed $surname
         */
        public function setSurname($surname)
        {
            $this->surname = $surname;
        }

        /**
         * @return mixed
         */
        public function getType()
        {
            return $this->type;
        }

        /**
         * @param mixed $type
         */
        public function setType($type)
        {
            $this->type = $type;
        }
        public static function findAll(): array {
            $con = Db::getInstance();
            $query = "SELECT * FROM ".self::TABLE;
            $stmt = $con->prepare($query);
            $stmt->setFetchMode(PDO::FETCH_CLASS, "user");
            $stmt->execute();
            $usersList  = array();
            while ($prod = $stmt->fetch())
            {
                $usersList[$prod->getId()] = $prod;
            }
            return $usersList;
        }
        public static function findById(int $id): ?user {
            $con = Db::getInstance();
            $query = "SELECT * FROM ".self::TABLE." WHERE id = $id";
            $stmt = $con->prepare($query);
            $stmt->setFetchMode(PDO::FETCH_CLASS, "user");
            $stmt->execute();
            if ($prod = $stmt->fetch())
            {
                return $prod;
            }
            return null;
        }
        public static function findByAccount($username,$password): ?user {
            $con = Db::getInstance();
            $query = "SELECT * FROM ".self::TABLE." WHERE username = '$username' AND passwd ='$password'";
            $stmt = $con->prepare($query);
            $stmt->setFetchMode(PDO::FETCH_CLASS, "user");
            $stmt->execute();
            if ($user = $stmt->fetch())
            {
                return $user;
            }
            return null;
        }
        public static function findByUsername($username): ?user {
            $con = Db::getInstance();
            $query = "SELECT * FROM ".self::TABLE." WHERE username = '$username'";
            $stmt = $con->prepare($query);
            $stmt->setFetchMode(PDO::FETCH_CLASS, "user");
            $stmt->execute();
            if ($user = $stmt->fetch())
            {
                return $user;
            }
            return null;
        }
        public function insert() {
            $con = Db::getInstance();
            $values = "";
            $this->setId($con->lastInsertId());
            foreach ($this as $prop => $val) {
                $values .= "'$val',";
            }
            $values = substr($values,0,-1);
            $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
            //echo $query;
            $res = $con->exec($query);
            return $res;

        }
        public function update() {
            $query = "UPDATE ".self::TABLE." SET ";
            foreach ($this as $prop => $val) {
                $query .= " $prop='$val',";
            }
            $query = substr($query, 0, -1);
            $query .= " WHERE id = ".$this->getId();
            $con = Db::getInstance();
            $res = $con->exec($query);
            return $res;
        }
        public static function changepass($username,$passwd) {
            $query = "UPDATE ".self::TABLE." SET passwd='$passwd' ";
            $query .= " WHERE username = '$username' ";
            $con = Db::getInstance();
            $res = $con->exec($query);
            return $res;
        }








    }
?>