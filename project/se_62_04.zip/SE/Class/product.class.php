<?php
    class Product
    {   private $cat_Id;
        private $product_Id;
        private $product_Name;
        private $status;
        private const TABLE = "product";
        /**
         * @return mixed
         */
        public function getCatId()
        {
            return $this->cat_Id;
        }

        /**
         * @param mixed $cat_Id
         */
        public function setCatId($cat_Id): void
        {
            $this->cat_Id = $cat_Id;
        }

        /**
         * @return mixed
         */
        public function getProductId()
        {
            return $this->product_Id;
        }

        /**
         * @param mixed $product_Id
         */
        public function setProductId($product_Id): void
        {
            $this->product_Id = $product_Id;
        }

        /**
         * @return mixed
         */
        public function getProductName()
        {
            return $this->product_Name;
        }

        /**
         * @param mixed $product_Name
         */
        public function setProductName($product_Name): void
        {
            $this->product_Name = $product_Name;
        }

        /**
         * @return mixed
         */
        public function getStatus()
        {
            return $this->status;
        }

        /**
         * @param mixed $status
         */
        public function setStatus($status): void
        {
            $this->status = $status;
        }
        public static function findAll(): array {
            $con = Db::getInstance();
            $query = "SELECT * FROM ".self::TABLE;
            $stmt = $con->prepare($query);
            $stmt->setFetchMode(PDO::FETCH_CLASS, "Product");
            $stmt->execute();
            $productList  = array();
            while ($prod = $stmt->fetch())
            {
                $productList[$prod->getProductId()] = $prod;
            }
            return $productList;
        }
        public function insert() {
            $con = Db::getInstance();
            $values = "";
            //$this->setCatId($con->lastInsertId());
            foreach ($this as $prop => $val) {
                $values .= "'$val',";
            }
            $values = substr($values,0,-1);
            $query = "INSERT INTO ".self::TABLE." VALUES ($values)";
            //echo $query;
            $res = $con->exec($query);
            return $res;

        }
        public static function findByName($name): array {
            $con = Db::getInstance();
            $query = "SELECT * FROM ".self::TABLE." WHERE product_Name LIKE '%$name%'";
            $stmt = $con->prepare($query);
            $stmt->setFetchMode(PDO::FETCH_CLASS, "Product");
            $stmt->execute();
            $productList  = array();
            while ($prod = $stmt->fetch())
            {
                $productList[$prod->getProductId()] = $prod;
            }
            return $productList;
        }


    }
?>

