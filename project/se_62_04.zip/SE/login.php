<?php
include "./Class/user.class.php";
include "./Class/Db.class.php";
$username =$_POST["username"];
$password =$_POST["password"];
$user = user::findByAccount($username,$password);
if($user!=null)
{
    session_start();
    $_SESSION['users'] = $user;
    //3 -> นิสิต
    if($user->getType()==3)
        header('Location: H_Nisit.php');
    //1 -> อาจารย์
    else if($user->getType()==1)
        header('Location: H_Nisit.php');
    //2 -> เจ้าหน้าที่
    else if($user->getType()==2)
        header('Location: H_Admin.php');
}
else
{
    header('Location: index.php?s=2');
}



?>