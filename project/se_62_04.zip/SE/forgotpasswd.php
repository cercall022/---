<script>
    function Alert() {
        alert("ID นี้ไม่มีในระบบ");}
</script>
<?php
$sys=$_GET["s"];
if($sys==1)
{
    echo "<body onload=\"Alert();\" >";

}
?>

<div align="center">
    <form name="loginForm" id="loginForm" method="post" action="workshop/mail/sample_email.php">
        <div>
            <label style="display: inline-block; width: 90px; text-align: right;">USERNAME :</label>
            <input class="btn btn-default"  type="text" name="username" id="username"placeholder="ใส่IDเพื่อกู้รหัสผ่าน" required/>
        </div>
        <button type="submit" class="btn">ยืนยัน</button>
        <button type="reset" class="btn">ยกเลิก</button>
    </form>
    <a href="index.php">กลับหน้าเเรก</a>
</div>