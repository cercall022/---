
<?php
    include "LDAPKU.php";
    include "./Class/Db.class.php";
    include "./Class/user.class.php";
    $username=$_POST["username"];
    $password=$_POST["password"];
    $info=user_authen($username);
    //print_r($info);
    if($info[count] == 1)
        {   echo"123";
            $a =new user();
            $a->setUsername($username);
            $a->setPasswd($password);
            $a->setName($info[0]["first-name"][0]);
            $a->setSurname($info[0]["last-name"][0]);
            $a->setType($info[0]["type-person"][0]);
            /*$a->setName("a");
            $a->setSurname("b");
            $a->setType(3);*/
            //print_r($a);
            $a->insert();
            print_r($a->findAll());

            header('Location: index.php?s=1');


        }
    else
        header('Location: register.php?error=1');
?>