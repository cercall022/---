<?php
include "Class/Db.class.php";
include "Class/user.class.php";
$username = $_POST["username"];
$passwd = $_POST["password"];
$cpasswd = $_POST["confirmpassword"];
echo $username.$passwd.$cpasswd;
if($passwd!=$cpasswd)
    header('Location: changepasswd.php?s=1');
else
    {
        user::changepass($username,$passwd);
        header('Location: index.php?s=4');
    }

?>