<?php
include "./Class/user.class.php";

include "func.php";
include "./Class/product.class.php";
include "./Class/Db.class.php";
include "./Class/category.class.php";
user::changepass("b6020502074",555);
print_r(user::findByUsername("b6020502074"));

?>