<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>

<link rel="stylesheet" href="tab.css">
<div class="logo">• ระบบยืมคืนอุปกรณ์ CPE KPS</div>
<?php
   //include "header.php";
    $err=$_GET["error"];
    if($err==1)
    {
        echo "<div align=\"center\">กรุณาใช้ ID นนทรีในการลงทะเบียนกับระบบ<br>ex.(b602050****,b612050***) </div>";
    }
?>

<script>
    function checkpassword() {
        var passwd = document.getElementById("password");
        var confirmpasswd = document.getElementById("confirmpassword");
        var text =document.getElementById("test");
        if(passwd.value!==confirmpasswd.value)
        {
            text.innerHTML="กรุณากรอก Password ให้ตรงกัน";}
        else
        {
            text.innerHTML="";
        }
    }

</script>

<div align="center">
    <form name="loginForm" id="loginForm" method="post" action="check.php">
        <fieldset style="width:30%">
            <br/>
            <span style="color: #ffffff;"><legend style="background-color:#595853 ;"><font color="#efefef">REGISTER :</font></legend></span>


            <div>
                    <label style="display: inline-block; width: 90px; text-align: right;" for="username">USERNAME: </label>
                    <input class="btn btn-default" type="text" name="username" id="username" >

                </div>
                <div>
                    <label style="display: inline-block; width: 90px; text-align: right;" for="password" width="100px">PASSWORD: </label>
                    <input class="btn btn-default" type="password" name="password" id="password" >
                </div>
                <div>
                    <label style="display: inline-block;  text-align: right;" for="password" >CONFIRM PW: </label>
                    <input class="btn btn-default" type="password" name="confirmpassword" id="confirmpassword" onkeyup="checkpassword()">
                </div>
            <div id="test"><font color="red"></font></div>

                <br/>
                <button type="submit" class="btn">Submit</button>
                <button type="reset" class="btn" onclick="location.href='index.php'">Back</button>

        </fieldset>
    </form>
    </div>

