<?php
function showTable(array $header,array $data,$check){
    //error_reporting(0);
    echo "<table>";
    echo "<tr>";

    foreach ($header as $h)
    {
        echo "<th>$h</th>";
    }
    echo "</tr>";
    foreach ($data as $row) {

            echo"<tr>";

        foreach ($row as $col){
            echo "<td>$col</td>";
              if(!next($row))
              {
                  if($check==1&&$col==="ถูกยืม")
                  {
                      echo "<td>ไม่สามารถยืมได้</td>";
                  }
                  else if($check==1&&$col==="ว่าง")
                  {
                      echo "<td><a href=\"#\">ยืมอุปกรณ์</a></td>";
                  }
              }



        }

        if($check==3)
        {echo "<td><a href=\"#\">เเก้ไขข้อมูล</a></td>";}
        echo "</tr>";

    }
    echo "</table>";

}
    function FindCatName($id_cat)
    {
        $cat = Category::findById($id_cat);

        return $cat->getCatName();
    }
?>