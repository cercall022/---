<?php
    include "../Class/category.class.php";
    include "../Class/Db.class.php";
     $cat_Id=$_POST["cat_Id"];
     $cat_Name=$_POST["cat_Name"];
     echo $cat_Id.$cat_Name;
     $cat=new Category();
     $cat->setCatId($cat_Id);
     $cat->setCatName($cat_Name);
     //print_r($cat);
     $cat->insert();
     //print_r(Category::findAll());
     header('Location: Insert_cat.php?s=1');

?>