<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<?php
        include "../Class/Db.class.php";
        include "../Class/category.class.php";
?>
<script>
    function Alert() {
        alert("เพิ่มอุปกรณ์เสร็จสิ้น");}
</script>
<?php
$sys=$_GET["s"];
if($sys==1)
{
    echo "<body onload=\"Alert();\" >";

}
?>
<style>
    div.ex1 {
        margin-top: 40px;
    }
</style>
<div align="center" class="ex1">
<form name="INproductForm" id="INproductForm" method="post" action="InToDB_product.php">
<fieldset style="width: 50%;" >
    <legend>เพิ่มอุปกรณ์</legend>
    <div>
        <label>ID หมวดหมู่: </label>
        <select name="cat_Id">
            <?php
            $a =Category::findAll();
            $arr =array();
            $i=0;
            foreach ($a as $d)
            {
                $arr[$i]=array($d->getCatId(),$d->getCatName());
                $i++;
            }
            foreach ($arr as $data)
            {$str=$data[0]."-".$data[1];
                echo "<option value=$data[0]>$str</option>";}
                echo "</select>"


            ?>
        </select>
    </div>

    <div >
        <label>ID อุปกรณ์: </label>
        <input class="btn btn-default" type="text" name="product_Id" id="product_Id" required/>
    </div>
    <div>
        <label>ชื่ออุปกรณ์: </label>
        <input class="btn btn-default" type="text" name="product_Name" id="product_Name" required/>
    </div>
    <br/>
    <button type="submit" class="btn">เพิ่มหมวดอุปกรณ์</button>
    <button type="reset" class="btn" onclick="location.href='../UI_manage.php'">กลับ</button>

</fieldset>

</form>
</div>
