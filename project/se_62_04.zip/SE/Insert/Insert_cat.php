<link rel="stylesheet" href="https://www.w3schools.com/w3css/4/w3.css">
<meta name="viewport" content="width=device-width, initial-scale=1">
<link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
<script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
<script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
<script>
    function Alert() {
        alert("เพิ่มหมวดอุปกรณ์เสร็จสิ้น");}
</script>
<?php

$sys=$_GET["s"];
if($sys==1)
{
    echo "<body onload=\"Alert();\" >";

}
?>
<style>
    div.ex1 {
        margin-top: 40px;
    }
</style>
<div align="center" class="ex1">
<form name="INcatForm" id="INcatForm" method="post" action="InToDB_cat.php">
<fieldset style="width: 50%;">
    <legend>เพิ่มหมวดหมู่อุปกรณ์</legend>
    <div>
        <label>ID หมวดหมู่: </label>
        <input class="btn btn-default" type="text" name="cat_Id" id="cat_Id" required/>
    </div>
    <div>
        <label>ชื่อหมวดหมู่: </label>
        <input class="btn btn-default" type="text" name="cat_Name" id="cat_Name" required/>
    </div>
    <br/>
    <button type="submit" class="btn">เพิ่มหมวดอุปกรณ์</button>
    <button type="reset" class="btn" onclick="location.href='../UI_manage.php'">กลับ</button>

</fieldset>
</form>
</div>