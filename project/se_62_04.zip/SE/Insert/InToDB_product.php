<?php
    include "../Class/Db.class.php";
    include "../Class/product.class.php";
    $cat_Id=$_POST["cat_Id"];
    $product_Id=$_POST["product_Id"];
    $product_Name=$_POST["product_Name"];
    echo "catId:".$cat_Id."Pid:".$product_Id."Pname:".$product_Name;
    echo"test";
    $data =new Product();
    $data->setCatId($cat_Id);
    $data->setProductId($product_Id);
    $data->setProductName($product_Name);
    $data->setStatus("ว่าง");
    //print_r($data);
    $data->insert();
    header('Location: Insert_product.php?s=1');
?>